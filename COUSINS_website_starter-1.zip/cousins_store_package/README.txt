COUSINS — LUXURY BRAND COLLECTIONS
Your starter storefront.

HOW TO PREVIEW:
1. Extract this ZIP.
2. Open index.html in a browser.
3. Keep the images folder beside index.html.

BEFORE ACCEPTING ORDERS:
- Replace "Price: To be added" with confirmed prices.
- Add available sizes, fabric composition, and stock status.
- Add your real WhatsApp business number and Instagram handle.
- Use your own original product photos, ideally clean product photos without marketplace/social-media interface overlays.
- Confirm delivery charges, return/exchange policy, and payment method.

This is a static starter website, not yet a live online store. It does not process payments or save orders.
